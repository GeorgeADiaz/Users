package com.formacionbdi.springboot.app.loggin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServiciosProductos1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
