package com.formacionbdi.springboot.app.loggin.models.service;

import java.util.List;

import com.formacionbdi.springboot.app.loggin.models.entity.Users;


public interface IUserService {

	public List<Users> findAll();
	public Users findById(Long id);
}
