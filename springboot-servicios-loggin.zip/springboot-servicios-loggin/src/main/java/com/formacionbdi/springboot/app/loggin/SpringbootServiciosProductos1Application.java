package com.formacionbdi.springboot.app.loggin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootServiciosProductos1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootServiciosProductos1Application.class, args);
	}

}
