package com.formacionbdi.springboot.app.loggin.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.formacionbdi.springboot.app.loggin.models.entity.Users;
import com.formacionbdi.springboot.app.loggin.models.service.IUserService;


@RestController
public class UserController {

	@Autowired
	private IUserService userService;
	
	@PostMapping("/listar")
	public List<Users> listar(){
		return userService.findAll();
	}
	
	@GetMapping("/listar/{id}")
	public Users detalle (@PathVariable Long id) {
		return userService.findById( id);
	}
	
	
}
