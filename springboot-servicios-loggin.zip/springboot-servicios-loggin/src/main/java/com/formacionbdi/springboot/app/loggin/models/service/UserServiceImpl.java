package com.formacionbdi.springboot.app.loggin.models.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.formacionbdi.springboot.app.loggin.models.dao.UserDao;
import com.formacionbdi.springboot.app.loggin.models.entity.Users;


public class UserServiceImpl implements IUserService {

	@Autowired
	private UserDao userDao;
	
	@Override
	public List<Users> findAll() {
		return (List<Users>)userDao.findAll();
	}

	@Override
	public Users findById(Long id) {
		return userDao.findById(id).orElse(null);
	}

}
