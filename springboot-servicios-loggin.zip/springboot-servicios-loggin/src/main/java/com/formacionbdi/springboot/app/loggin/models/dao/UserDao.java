package com.formacionbdi.springboot.app.loggin.models.dao;

import org.springframework.data.repository.CrudRepository;

import com.formacionbdi.springboot.app.loggin.models.entity.Users;

public interface UserDao extends CrudRepository<Users, Long>{

}
